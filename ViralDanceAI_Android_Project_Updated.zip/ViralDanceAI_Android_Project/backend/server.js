const express = require('express');
const cors = require('cors');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;
const uploadDir = path.join(os.tmpdir(), 'viral-dance-ai-test-uploads');
fs.mkdirSync(uploadDir, { recursive: true });
app.use(cors());
app.use(express.json({ limit: '1mb' }));
const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 200 * 1024 * 1024, files: 2 },
  fileFilter: (_req, file, cb) => {
    const ok = file.fieldname === 'danceVideo'
      ? file.mimetype.startsWith('video/')
      : file.fieldname === 'characterImage' && file.mimetype.startsWith('image/');
    cb(ok ? null : new Error('Unsupported file type.'), ok);
  }
});
const jobs = new Map();

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Viral Dance AI test backend', aiRendering: false }));

app.post('/api/jobs', upload.fields([{ name: 'danceVideo', maxCount: 1 }, { name: 'characterImage', maxCount: 1 }]), (req, res) => {
  const video = req.files?.danceVideo?.[0];
  const image = req.files?.characterImage?.[0];
  if (!video || !image) return res.status(400).json({ error: 'Both danceVideo and characterImage are required.' });
  let settings = {};
  try { settings = JSON.parse(req.body.settings || '{}'); }
  catch { return res.status(400).json({ error: 'settings must be valid JSON.' }); }
  const jobId = crypto.randomUUID();
  jobs.set(jobId, { jobId, status: 'queued', message: 'Files received. This is a workflow test only.', createdAt: Date.now(), files: [video.path, image.path], settings });
  setTimeout(() => {
    const job = jobs.get(jobId);
    if (job) { job.status = 'completed'; job.message = 'Upload and job tracking test passed. No AI video was rendered.'; }
  }, 5000);
  res.status(202).json({ jobId, status: 'queued', aiRendering: false });
});

app.get('/api/jobs/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found.' });
  res.json({ jobId: job.jobId, status: job.status, message: job.message, aiRendering: false });
});

app.use((err, _req, res, _next) => {
  const code = err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
  res.status(code).json({ error: err.message || 'Request failed.' });
});

app.listen(port, () => console.log(`Viral Dance AI test backend listening on ${port}`));
