# Viral Dance AI — test backend (not an AI renderer)

This small Node.js service is provided only to verify the Android app's upload and job-status workflow. It accepts a dance video and character image, creates a temporary test job, and marks that job complete after a few seconds. **It does not perform motion transfer, face replacement, or generate a video.**

## Run it on a server you control

1. Install Node.js 20 or newer.
2. In this `backend` folder, run `npm install`.
3. Run `npm start`.
4. The health check is `GET /health`.
5. Set the app's Backend server URL to the server's HTTPS base URL (do not add `/api`).

The app sends `POST /api/jobs` as multipart form data with `danceVideo`, `characterImage`, and a JSON `settings` field. It polls `GET /api/jobs/:jobId` for status.

## Important limitations

- Jobs are held in memory and disappear when the server restarts.
- Uploaded files are saved temporarily in the operating system temp folder; this demo does not implement retention cleanup, authentication, private storage, rate limiting, or production security.
- Do not deploy this demo with personal or sensitive media. Use only test files you have permission to upload.
- There is no AI inference engine, generated video, or output download endpoint in this test service.
- A production deployment must add authentication, secure object storage, cleanup policies, abuse protection, and a real licensed AI inference provider. Keep provider secrets on the server, never in the APK.
