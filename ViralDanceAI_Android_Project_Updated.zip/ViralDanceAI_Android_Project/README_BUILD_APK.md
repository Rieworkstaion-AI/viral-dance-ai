# Viral Dance AI — Android project

This project contains the Android wrapper UI and an optional test backend scaffold.

## Build the Android APK with GitHub Actions

The repository workflow supplied separately (`.github/workflows/build-apk.yml`) extracts this project ZIP, installs Capacitor dependencies, creates the Android project, and builds a debug APK. After the workflow succeeds, download the `viral-dance-ai-debug-apk` artifact and extract `app-debug.apk` on your phone.

## Current app functionality

- Select and preview a dance video and character image.
- Configure full-body / face replacement mode, aspect ratio, resolution, duration, identity lock, and background setting.
- Run an on-device workflow simulation when the Backend server URL is blank.
- If a test backend is deployed and its HTTPS URL is entered, upload the two selected files and poll the test job status.

## Important: this is not yet an AI video generator

The included backend is a workflow-test service only. It verifies upload and job tracking, then reports completion. It does **not** generate a dance-transfer video, replace a face, or return a rendered video. A real AI generation service still needs to be selected, deployed, secured, and integrated. Free GPU processing is not guaranteed.

## Optional test backend

See `backend/README.md`. It requires Node.js 20+ and is intended for controlled testing only. Do not upload private media to an unsecured demo deployment.

## Build locally (computer required)

1. Extract this ZIP.
2. Open a terminal in the `ViralDanceAI_Android_Project` folder.
3. Run `npm install`.
4. Run `npx cap add android` (skip if `android/` already exists).
5. Run `npx cap sync android`.
6. Open with Android Studio and build a debug APK, or use the repository's GitHub Actions workflow.

Only upload footage and likenesses you own or have permission to use. Never put private AI provider API keys in the Android app.
